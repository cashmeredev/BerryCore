# tmux 3.3a for QNX/BB10

**Terminal multiplexer for BlackBerry QNX 8**

## What is tmux?

tmux is a terminal multiplexer that allows you to:
- Run multiple terminal sessions in one window
- Split your screen into panes (horizontal/vertical)
- Detach and reattach sessions (survive disconnects!)
- Create persistent background sessions

## Installation

```bash
qpkg install tmux
```

## Quick Start

```bash
# Start tmux
tmux

# Create a new session with a name
tmux new-session -s mysession

# List all sessions
tmux ls

# Attach to a session
tmux attach -t mysession

# Detach from session (keep it running)
# Press: Ctrl+b, then d
```

## Essential Keybindings

All commands start with **Ctrl+b** (press and release), then:

### Panes (splits)
- `"` - Split horizontally
- `%` - Split vertically  
- Arrow keys - Navigate between panes
- `o` - Cycle through panes
- `z` - Zoom/unzoom current pane
- `x` - Kill current pane

### Windows (tabs)
- `c` - Create new window
- `n` - Next window
- `p` - Previous window
- `0-9` - Jump to window number
- `,` - Rename window
- `w` - List all windows

### Sessions
- `d` - Detach from session
- `s` - List all sessions
- `(` - Previous session
- `)` - Next session

### Other
- `?` - Show all keybindings
- `:` - Command prompt

## Common Use Cases

### Split screen for monitoring
```bash
tmux
# Press Ctrl+b, then "
# Press Ctrl+b, then arrow keys to navigate
# Run different commands in each pane
```

### Persistent SSH sessions
```bash
# Start tmux before running long tasks
tmux new -s work
# Run your command
# Press Ctrl+b, d to detach
# Your session keeps running!
# Later: tmux attach -s work
```

### Multiple projects
```bash
tmux new -s project1
tmux new -s project2
tmux ls              # See all sessions
tmux attach -t project1
```

## Configuration

Create `~/.tmux.conf` to customize:
```bash
# Example config
set -g mouse on                    # Enable mouse support
set -g history-limit 10000         # More scrollback
set -g status-style bg=blue        # Blue status bar
```

## Notes for QNX

- Uses BSD-style PTYs (`/dev/ptyp*`)
- Sockets stored in `~/t/` to fit path limits
- TERM set to `ansi` by default (QNX compatible)
- Uses BerryCore bash by default

## Technical Details

- **Version**: 3.3a
- **Binary size**: ~734KB
- **Dependencies**: libevent 2.1.12, ncursesw
- **Libraries included**: Yes (bundled libevent)

## Troubleshooting

### "missing or unsuitable terminal"
The wrapper script sets TERM=ansi automatically, but if you run `tmux.bin` directly, set it manually:
```bash
export TERM=ansi
```

### Shell exits immediately
Make sure bash is available at:
```bash
/accounts/1000/shared/misc/berrycore/bin/bash
```

### Can't find sessions
Check socket directory:
```bash
ls ~/t/*/
```

## Links

- tmux homepage: https://github.com/tmux/tmux
- tmux manual: `man tmux` (on systems with man pages)
- QNX port by: BerryCore project

## Version History

- **3.3a** (2025-10-27): Initial QNX port with BSD-style PTY support

---

**Enjoy tmux on your BlackBerry!** 🎉
