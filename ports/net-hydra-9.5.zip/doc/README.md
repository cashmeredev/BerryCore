# THC-Hydra 9.5 for BlackBerry QNX

## What is Hydra?

THC-Hydra is a fast and flexible network login cracker supporting 50+ protocols.

## Version Information

- **Version**: 9.5
- **Architecture**: ARM (QNX)
- **OpenSSL**: Uses system OpenSSL (no bundled libraries)
- **Compiled**: October 2025

## What's Included

- `hydra` - Main network login cracker
- `pw-inspector` - Password quality inspector

## Supported Protocols

FTP, HTTP(S), IMAP, LDAP, MSSQL, MySQL, NNTP, Oracle, POP3, PostgreSQL, RDP, Redis, RTSP, SIP, SMB, SMTP, SNMP, SOCKS5, SSH, Telnet, VNC, XMPP, and many more!

## Installation

```bash
# Installed via BerryCore package manager
qpkg install hydra

# Or manually extract to $NATIVE_TOOLS
unzip -o net-hydra-9.5.zip
```

## Basic Usage

```bash
# Test SSH login
hydra -l username -P passwords.txt ssh://192.168.1.100

# Test HTTP basic auth
hydra -l admin -P passwords.txt 192.168.1.100 http-get /admin

# Test FTP
hydra -L users.txt -P passwords.txt ftp://192.168.1.100

# Show help
hydra -h
```

## Requirements

Requires system libraries:
- libssl.so.2 (OpenSSL 1.0.x - included with QNX)
- libcrypto.so.2 (OpenSSL 1.0.x - included with QNX)
- libncursesw.so.1 (ncurses - included with QNX)

## Important Notes

⚠️ **Legal Use Only**: This tool is for authorized security testing only. Unauthorized access is illegal.

## Examples

### Web Form Login
```bash
hydra -l admin -P passwords.txt 192.168.1.100 http-post-form \
  "/login:username=^USER^&password=^PASS^:Invalid credentials"
```

### SSH with User List
```bash
hydra -L users.txt -P passwords.txt ssh://192.168.1.100 -t 4
```

## Documentation

Full docs: https://github.com/vanhauser-thc/thc-hydra

## License

AGPL v3.0 - https://github.com/vanhauser-thc/thc-hydra/blob/master/LICENSE

---

**Use Responsibly** 🔒

