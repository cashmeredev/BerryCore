# THC-Hydra 9.5 for BlackBerry QNX 8

## What is Hydra?

THC-Hydra is a fast and flexible network login cracker that supports numerous protocols. It is a proof-of-concept tool to demonstrate how easy it would be to gain unauthorized access to a system remotely.

## Version Information

- **Version**: 9.5
- **Architecture**: ARM (BlackBerry QNX 8)
- **Compiled**: October 2025
- **OpenSSL**: 3.3.2 (bundled)

## What's Included

- `hydra` - Main network login cracker
- `pw-inspector` - Password quality inspector tool
- OpenSSL 3.3.2 libraries (libssl.so.3, libcrypto.so.3)

## Supported Protocols

This build supports the following protocols:

- FTP, HTTP(S), IMAP, LDAP, MSSQL, MySQL, NNTP, Oracle
- POP3, PostgreSQL, RDP, Redis, RTSP, SIP, SMB, SMTP
- SNMP, SOCKS5, SSH, Telnet, VNC, XMPP
- And many more...

**Disabled modules** (due to missing dependencies):
- libssh-based SSH (uses built-in SSH instead)
- PostgreSQL client (basic auth only)
- Firebird, SAP/R3, NCP, AFP, MongoDB (libraries not available)

## Installation

Installed via BerryCore package manager:
```bash
qpkg install hydra
```

## Basic Usage

```bash
# Test SSH login
hydra -l username -P passwords.txt ssh://192.168.1.100

# Test HTTP basic auth
hydra -l admin -P passwords.txt 192.168.1.100 http-get /admin

# Test FTP
hydra -L users.txt -P passwords.txt ftp://192.168.1.100

# Test multiple targets
hydra -l admin -p password -M targets.txt ssh

# Show help
hydra -h
```

## Environment Setup

The libraries are installed to `$NATIVE_TOOLS/lib` and should be automatically found. If you encounter library loading issues:

```bash
export LD_LIBRARY_PATH=$NATIVE_TOOLS/lib:$LD_LIBRARY_PATH
```

## Password Lists

You can use `pw-inspector` to filter and validate password lists:

```bash
# Filter passwords: min 6 chars, max 10 chars
pw-inspector -m 6 -M 10 -i wordlist.txt -o filtered.txt

# Allow only lowercase and numbers
pw-inspector -l -n -i wordlist.txt -o filtered.txt
```

## Important Notes

1. **Legal Use Only**: This tool is for authorized security testing only. Unauthorized access to computer systems is illegal.

2. **OpenSSL 3.3.2**: This build includes OpenSSL 3.3.2 libraries for SSL/TLS support.

3. **Performance**: Network speed and target system response times will affect cracking speed.

4. **Parallel Tasks**: Use `-t` flag to control parallel connections (default: 16)
   ```bash
   hydra -t 4 -l admin -P passwords.txt ssh://target
   ```

## Troubleshooting

### "cannot open shared object file: libssl.so.3"
Make sure you've installed the package via qpkg, which sets up library paths correctly.

### Slow Performance
- Reduce parallel tasks with `-t` flag
- Check network latency to target
- Some protocols (like SSH) are intentionally slow to prevent brute-forcing

### Module Not Found
Some modules require libraries that aren't available on QNX. Use `hydra -h` to see available modules.

## Examples

### Web Form Login
```bash
hydra -l admin -P passwords.txt 192.168.1.100 http-post-form \
  "/login:username=^USER^&password=^PASS^:Invalid credentials"
```

### SSH with User List
```bash
hydra -L users.txt -P passwords.txt ssh://192.168.1.100 -t 4
```

### HTTPS Basic Auth
```bash
hydra -l admin -P passwords.txt -s 443 192.168.1.100 https-get /
```

## Documentation

For full documentation, visit: https://github.com/vanhauser-thc/thc-hydra

## License

THC-Hydra is licensed under AGPL v3.0
See: https://github.com/vanhauser-thc/thc-hydra/blob/master/LICENSE

## Credits

- **THC-Hydra**: The Hacker's Choice (van Hauser and David Maciejak)
- **QNX Port**: Cross-compiled for BlackBerry QNX 8 ARM
- **OpenSSL**: OpenSSL 3.3.2 bundled for SSL/TLS support

---

**Use Responsibly** 🔒

